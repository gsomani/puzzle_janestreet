# SPICE-to-Verilog: how the `puzzle` netlist was reverse-engineered

This documents the process used to turn `extracted_netlist.spice` (a
transistor-level, sky130A-technology netlist) into a flattened, simulate-able
behavioral Verilog module. The companion script `netlist_to_verilog.py` is a
cleaned-up, reusable version of the one-off exploration below — run it
directly instead of retracing these steps by hand.

## 1. Get oriented in the file

```bash
wc -l netlist.spice                     # 2994 lines
grep -c "^\.subckt" netlist.spice       # 69 subcircuit definitions
grep -c "^X" netlist.spice              # 1890 instance lines total
```

Two layers live in this one file:

- **Standard-cell library** (69 `.subckt` blocks): each one is a *transistor-level*
  definition of one Sky130 HD standard cell (`sky130_fd_sc_hd__nand2_2`,
  `..__dfxtp_2`, etc.) — literally a handful of `pfet`/`nfet` instances wired
  together.
- **The actual design**: one more `.subckt`, near the end of the file, that
  *instantiates* those library cells to build the real circuit:

  ```
  .subckt puzzle I O[0] O[1] ... O[7] clk enable rst_n success VGND VPWR
  ```

  This is the target: a gate-level netlist for something called `puzzle`,
  with a serial input `I`, an 8-bit output bus `O`, `clk`/`enable`/`rst_n`
  control signals, and a `success` output. That port list (serial input +
  success flag) is a strong hint this is a sequence-detector / lock-style FSM
  — worth keeping in mind when reading the generated Verilog later.

Key insight: **we never need to simulate the transistors.** A standard cell's
whole purpose is to present a fixed, known boolean function behind a name
(`nand2`, `a21oi`, `dfxtp`, ...). Once we know each cell's function, "flatten
the netlist" becomes a substitution problem, not a circuit-simulation problem.

## 2. Find the top-level module automatically

Don't hardcode the name `puzzle` — detect it generically, since the same
approach should work on other extracted netlists:

> The top-level design subckt is the one `.subckt` that is **never itself
> instantiated** by any other `.subckt` in the file.

```python
candidates = [name for name in all_subckt_names if name not in instantiated_types]
# -> exactly one candidate = the top module
```

## 3. Parse pin names/order per cell type — from the file, not from memory

Different LVS extraction tools order a cell's ports differently. Rather than
assuming "sky130's `nand2` is always `(A, B, Y, ...)`", the port **order** is
read straight from each `.subckt` header in *this* file:

```python
.subckt sky130_fd_sc_hd__nand2_2  Y A B VGND VPWR VPB VNB
#                                  ^ this order is what matters
```

The **pin names** (`A`, `B`, `Y`, `A1`, `B1_N`, `RESET_B`, ...) *are*
standardized across the Sky130 HD library regardless of order, so functional
templates are written keyed by pin **name**, and are order-independent.

## 4. Build a boolean template per cell type

For every base cell type used in the design (stripped of the
`sky130_fd_sc_hd__` prefix and the trailing drive-strength suffix, e.g.
`sky130_fd_sc_hd__a21oi_2` → `a21oi`), write down its known truth table as a
Verilog expression, keyed by pin name:

| Naming pattern | Meaning | Example |
|---|---|---|
| `aXYZo[i]` | AND-groups of size X,Y,Z, OR'd together, optionally inverted | `a21oi`: `~((A1&A2)\|B1)` |
| `oXYZa[i]` | OR-groups of size X,Y,Z, AND'd together, optionally inverted | `o21ai`: `~((A1\|A2)&B1)` |
| trailing `b`/`bb`, or an `_N` pin suffix | that specific input is used inverted | `and2b`: `(~A_N) & B` |
| `dfxtp` / `dfrtp` / `dfstp` | D flip-flop: plain / async reset / async set | see below |
| `conb` | tie-off cell (constant 0 on `LO`, constant 1 on `HI`) | |
| `decap`, `diode` | no logic function at all (decoupling cap, antenna diode) | dropped entirely |

Sequential cells become `always` blocks instead of expressions:

```verilog
// dfrtp: async active-low reset
always @(posedge CLK or negedge RESET_B)
    if (!RESET_B) Q <= 1'b0;
    else          Q <= D;
```

## 5. Walk every top-level instance and substitute

For each `X<instance> <net> <net> ... <cell_type>` line in the top module:

1. Zip the cell's port-name list (from step 3) with the connected nets.
2. Drop the power/ground/body pins (`VPWR`, `VGND`, `VPB`, `VNB`) — pure
   power routing, no logic value.
3. Look up the cell's boolean template (step 4) and substitute in the
   connected net names to produce one `assign` (combinational) or one
   `always` block (sequential).
4. Sanitize net names into legal Verilog identifiers (SPICE nets like
   `a_281_297#` or `sky130_fd_sc_hd__inv_2_7/A` get non-alphanumeric
   characters replaced with `_`). A literal `VGND`/`VPWR` connection on a
   *logic* pin (used to tie an unused input) becomes the constant
   `1'b0`/`1'b1` instead of a wire.

## 6. Sanity-check before trusting the output

Before generating Verilog, verify the netlist is well-formed:

```python
# every net should have exactly one driver
assert no duplicate combinational output nets
assert no duplicate flip-flop Q nets
assert no net driven by more than one category (comb / flop / tie)
assert no nets read but never driven ("floating" nodes)
```

On this file all of these passed cleanly: 630 combinational gates, 92
flip-flops (84 `dfrtp` + 4 `dfxtp` + 4 `dfstp`), 12 tie-offs, zero floating
nets, zero multiply-driven nets.

## 7. Determine top-level port directions automatically

Rather than guessing, a port is classified as an **output** if it's ever
driven by some instance's output pin, and an **input** otherwise:

```
I       -> INPUT
clk     -> INPUT
enable  -> INPUT
rst_n   -> INPUT
O[0..7] -> OUTPUT (each bit driven by a combinational gate)
success -> OUTPUT (driven directly by a dfrtp flip-flop's Q — i.e. it's registered)
```

## 8. Emit the flattened Verilog module

Declare a `wire` per combinational net, a `reg` per flip-flop output, emit
the tie-off `assign`s, then all combinational `assign`s, then all `always`
blocks, and close the module. The result simulates identically to the
original gate-level netlist but needs no Sky130 cell library — just a
standard Verilog simulator.

## 9. Validate the result

- Structural checks: `module`/`endmodule` counts, matching `begin`/`end`
  counts (92 each, one pair per flip-flop), no null/error tokens.
- Traced `success` back through the generated code to confirm it really is a
  registered output of a `dfrtp` cell, matching the port-direction analysis.
- (Icarus Verilog wasn't available in this sandbox to do a full compile check
  — if you have it locally, `iverilog -g2012 puzzle.v` is worth running.)

## Files in this pack

- `netlist_to_verilog.py` — the reusable, commented version of the whole
  pipeline above. Run: `python3 netlist_to_verilog.py input.spice output.v`
- `README.md` — this file.

## Caveats / things to double check yourself

- The boolean templates for the ~65 cell types were written from memory of
  the public Sky130 HD cell library conventions, then cross-checked only by
  structural sanity (single-driver nets, balanced begin/end). They were
  **not** verified transistor-by-transistor against the actual `pfet`/`nfet`
  device lists in each `.subckt` — if you want full confidence, that's the
  next step (build a truth table from the transistor netlist for one cell of
  each type and compare against the template).
- Net names in the output are the raw sanitized SPICE names
  (`sky130_fd_sc_hd__a32o_2_4_X`, etc.) rather than meaningful signal names —
  fine for simulation, but you'll want to rename things once you start
  identifying which flip-flops form the FSM state.
